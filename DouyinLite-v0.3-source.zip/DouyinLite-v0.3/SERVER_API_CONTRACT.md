# DouyinLite backend contract (v0.3)

The iPhone and Apple Watch each call this endpoint independently:

`GET https://YOUR-DOMAIN.example/v1/douyin/hot?limit=8`

Optional query parameters:
- `cursor`: opaque next-page cursor returned by the previous response
- `keyword`: optional search term, if the approved backend supports search

## Response

```json
{
  "videos": [
    {
      "id": "platform-item-id",
      "title": "Video title",
      "author": "Creator",
      "video_url": "https://authorized-cdn.example/path/stream.m3u8",
      "share_url": "https://www.douyin.com/video/...",
      "cover_url": "https://example.com/cover.jpg"
    }
  ],
  "next_cursor": "opaque-cursor-or-null"
}
```

`videos` contains only the current page. Return at most the requested `limit` (the app requests 8). Return `next_cursor: null` when no more pages are available.

## URL semantics

- `video_url`: optional direct MP4/HLS media URL, only when the platform or rights-holder explicitly authorizes playback in this app. This is the only URL passed to `AVPlayer`.
- `share_url`: optional human-facing video/playback page. It is opened as a webpage and is never passed to `AVPlayer`.
- `cover_url`: optional image URL. It is never passed to `AVPlayer`.

Do not convert a share page into a guessed media URL.

## Official-source limitation

The official Douyin Hot Video Ranking capability describes ranking metadata and a video playback-page link. It is an offline ranking dataset refreshed daily; that does not establish a universal real-time recommendation feed or an AVPlayer-ready MP4/HLS URL. Video search capability also does not by itself promise direct third-party media playback URLs.

Before enabling public Douyin content:
1. Obtain the relevant Douyin Open Platform app capability and approval.
2. Confirm the permitted use and display/playback rights for the intended third-party app.
3. Deploy a backend that calls only approved APIs.
4. Populate `video_url` only with an explicitly authorized media URL.
5. Keep app secrets and tokens on the server.

Do not reverse-engineer private endpoints, steal/replay cookies, bypass signatures, or evade access controls.

## Operational recommendations

- Use HTTPS only.
- Apply server-side rate limiting and token refresh.
- Use short-lived signed playback URLs where supported.
- Return a stable unique `id` for each video.
- Avoid returning an unbounded list; honor `limit` and cursor pagination.
- The app does not persist feed history or download video files to its own storage.
