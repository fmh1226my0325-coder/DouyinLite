import SwiftUI
import AVKit

struct WatchFeedView: View {
    @StateObject private var service = FeedService()
    @StateObject private var playback = VideoPlaybackManager()
    @State private var currentIndex = 0

    private var currentVideo: VideoItem? {
        guard service.videos.indices.contains(currentIndex) else { return nil }
        return service.videos[currentIndex]
    }

    var body: some View {
        Group {
            if let video = currentVideo {
                videoView(video)
            } else {
                emptyState
            }
        }
        .task {
            await service.loadInitialPage()
            playCurrent()
        }
        .onChange(of: currentIndex) { _, _ in
            playCurrent()
        }
        .onChange(of: service.videos.count) { _, _ in
            if currentVideo == nil, !service.videos.isEmpty {
                currentIndex = 0
                playCurrent()
            }
        }
        .onDisappear {
            playback.stopAndRelease()
        }
    }

    private func videoView(_ video: VideoItem) -> some View {
        ScrollView {
            VStack(spacing: 7) {
                if let player = playback.player, video.videoURL != nil {
                    VideoPlayer(player: player)
                        .frame(height: 132)
                        .clipShape(RoundedRectangle(cornerRadius: 9))
                } else {
                    VStack(spacing: 5) {
                        Image(systemName: "play.slash").font(.title2)
                        Text(video.videoURL == nil ? "此条没有授权播放流" : "正在准备播放")
                            .font(.caption2)
                        if let shareURL = video.shareURL {
                            Link("打开视频页", destination: shareURL)
                                .font(.caption2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 110)
                    .background(.gray.opacity(0.15))
                    .clipShape(RoundedRectangle(cornerRadius: 9))
                }

                Text(video.title)
                    .font(.caption)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("@\(video.author)")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                HStack {
                    Button {
                        previous()
                    } label: {
                        Image(systemName: "chevron.left")
                    }
                    .disabled(currentIndex == 0)

                    Spacer()

                    Text("\(currentIndex + 1)")
                        .font(.caption2)
                        .monospacedDigit()

                    Spacer()

                    Button {
                        next()
                    } label: {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(currentIndex + 1 >= service.videos.count && !service.hasMorePages)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 5)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "play.rectangle").font(.title2)
            Text(service.errorMessage ?? "加载中…")
                .font(.caption2)
                .multilineTextAlignment(.center)
            Button("重试") {
                Task { await service.loadInitialPage(force: true); currentIndex = 0; playCurrent() }
            }
            .disabled(service.isLoading)
        }
        .padding(8)
    }

    private func playCurrent() {
        guard let video = currentVideo else {
            playback.stopAndRelease()
            return
        }
        playback.play(video)
        let nextIndex = currentIndex + 1
        let nextVideo = service.videos.indices.contains(nextIndex) ? service.videos[nextIndex] : nil
        playback.preload(nextVideo)
        Task { await service.loadNextPageIfNeeded(after: video) }
    }

    private func next() {
        if currentIndex + 1 < service.videos.count {
            currentIndex += 1
        } else if service.hasMorePages {
            Task {
                guard let last = service.videos.last else { return }
                await service.loadNextPageIfNeeded(after: last)
                if currentIndex + 1 < service.videos.count {
                    currentIndex += 1
                }
            }
        }
    }

    private func previous() {
        guard currentIndex > 0 else { return }
        currentIndex -= 1
    }
}
