import Foundation

struct VideoItem: Identifiable, Decodable, Hashable {
    let id: String
    let title: String
    let author: String
    let videoURL: URL?
    let shareURL: URL?
    let coverURL: URL?

    enum CodingKeys: String, CodingKey {
        case id, title, author
        case videoURL = "video_url"
        case shareURL = "share_url"
        case coverURL = "cover_url"
    }
}

struct FeedPage: Decodable {
    let videos: [VideoItem]
    let nextCursor: String?

    enum CodingKeys: String, CodingKey {
        case videos
        case nextCursor = "next_cursor"
    }
}
