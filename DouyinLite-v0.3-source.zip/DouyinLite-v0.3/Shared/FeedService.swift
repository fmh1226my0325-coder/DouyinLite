import Foundation
import Combine

@MainActor
final class FeedService: ObservableObject {
    @Published private(set) var videos: [VideoItem] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isLoadingNextPage = false
    @Published private(set) var hasMorePages = true
    @Published var errorMessage: String?

    // Replace with your own HTTPS backend. Never embed Open Platform secrets here.
    private let feedURLString = "https://YOUR-DOMAIN.example/v1/douyin/hot"
    private let pageSize = 8
    private var nextCursor: String?
    private var hasRequestedFirstPage = false

    func loadInitialPage(force: Bool = false) async {
        guard !isLoading else { return }
        if hasRequestedFirstPage && !force { return }

        isLoading = true
        defer { isLoading = false }

        if force {
            videos.removeAll(keepingCapacity: false)
            nextCursor = nil
            hasMorePages = true
        }

        do {
            let page = try await fetchPage(cursor: nil)
            videos = uniqueVideos(page.videos)
            nextCursor = page.nextCursor
            hasMorePages = page.nextCursor != nil
            hasRequestedFirstPage = true
            errorMessage = videos.isEmpty ? "暂无可展示的视频" : nil
        } catch {
            errorMessage = userFacingMessage(for: error)
        }
    }

    func loadNextPageIfNeeded(after video: VideoItem) async {
        guard let last = videos.last,
              last.id == video.id,
              hasMorePages,
              !isLoading,
              !isLoadingNextPage else { return }

        isLoadingNextPage = true
        defer { isLoadingNextPage = false }

        do {
            let page = try await fetchPage(cursor: nextCursor)
            let additions = uniqueVideos(page.videos)
            videos.append(contentsOf: additions)
            nextCursor = page.nextCursor
            hasMorePages = page.nextCursor != nil
            if videos.isEmpty {
                errorMessage = "暂无可展示的视频"
            } else {
                errorMessage = nil
            }
        } catch {
            errorMessage = userFacingMessage(for: error)
        }
    }

    func retry() async {
        if videos.isEmpty {
            await loadInitialPage(force: true)
        } else if let last = videos.last {
            await loadNextPageIfNeeded(after: last)
        }
    }

    private func fetchPage(cursor: String?) async throws -> FeedPage {
        guard var components = URLComponents(string: feedURLString),
              !feedURLString.contains("YOUR-DOMAIN") else {
            throw FeedError.backendNotConfigured
        }

        var queryItems = [URLQueryItem(name: "limit", value: String(pageSize))]
        if let cursor, !cursor.isEmpty {
            queryItems.append(URLQueryItem(name: "cursor", value: cursor))
        }
        components.queryItems = queryItems

        guard let url = components.url else { throw FeedError.invalidURL }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 20
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw FeedError.badServerResponse
        }
        return try JSONDecoder().decode(FeedPage.self, from: data)
    }

    private func uniqueVideos(_ incoming: [VideoItem]) -> [VideoItem] {
        var knownIDs = Set(videos.map(\.id))
        return incoming.filter { knownIDs.insert($0.id).inserted }
    }

    private func userFacingMessage(for error: Error) -> String {
        if let feedError = error as? FeedError {
            switch feedError {
            case .backendNotConfigured:
                return "尚未配置授权后端。请先设置 HTTPS 视频数据接口。"
            case .invalidURL:
                return "视频接口地址无效。"
            case .badServerResponse:
                return "服务器暂时无法提供视频，请稍后重试。"
            }
        }
        return "加载失败：\(error.localizedDescription)"
    }
}

private enum FeedError: Error {
    case backendNotConfigured
    case invalidURL
    case badServerResponse
}
