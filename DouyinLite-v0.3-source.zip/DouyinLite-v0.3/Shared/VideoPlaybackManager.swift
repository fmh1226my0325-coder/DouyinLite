import Foundation
import AVFoundation
import Combine

/// Each app process owns its own manager. The Watch never receives the iPhone's player or media data.
@MainActor
final class VideoPlaybackManager: ObservableObject {
    @Published private(set) var player: AVPlayer?

    private var activeVideoID: String?
    private var preparedURL: URL?
    private var preparedItem: AVPlayerItem?
    private var prepareTask: Task<Void, Never>?

    func play(_ video: VideoItem) {
        guard activeVideoID != video.id else {
            player?.play()
            return
        }

        releaseCurrentPlayer()
        activeVideoID = video.id

        guard let url = video.videoURL else { return }

        let item: AVPlayerItem
        if preparedURL == url, let preparedItem {
            item = preparedItem
            self.preparedItem = nil
            preparedURL = nil
        } else {
            item = AVPlayerItem(url: url)
        }

        let newPlayer = AVPlayer(playerItem: item)
        newPlayer.automaticallyWaitsToMinimizeStalling = true
        player = newPlayer
        newPlayer.play()
    }

    func preload(_ video: VideoItem?) {
        prepareTask?.cancel()
        preparedItem = nil
        preparedURL = nil

        guard let url = video?.videoURL else { return }
        prepareTask = Task {
            let asset = AVURLAsset(url: url)
            do {
                let playable = try await asset.load(.isPlayable)
                guard !Task.isCancelled, playable else { return }
                let item = AVPlayerItem(asset: asset)
                item.preferredForwardBufferDuration = 3
                guard !Task.isCancelled else { return }
                preparedURL = url
                preparedItem = item
            } catch {
                // Preloading is opportunistic. Normal playback will report any playback failure.
            }
        }
    }

    func replay(_ video: VideoItem) {
        releaseCurrentPlayer()
        activeVideoID = nil
        play(video)
    }

    func pause() {
        player?.pause()
    }

    func stopAndRelease() {
        prepareTask?.cancel()
        prepareTask = nil
        preparedItem = nil
        preparedURL = nil
        releaseCurrentPlayer()
    }

    private func releaseCurrentPlayer() {
        player?.pause()
        player?.replaceCurrentItem(with: nil)
        player = nil
        activeVideoID = nil
    }
}
