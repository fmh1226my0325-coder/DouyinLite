# DouyinLite v0.3 — iPhone + independent Apple Watch video feed

A minimal native SwiftUI project based on the supplied v0.2 source. The project keeps the existing bundle identifiers and the approved-backend architecture.

## What's changed in v0.3

- iPhone feed is a full-screen vertical, page-snapping video feed.
- iPhone and Apple Watch independently request the HTTPS feed endpoint.
- The Watch target owns its own `FeedService` and `VideoPlaybackManager`; it does not receive video bytes from the iPhone.
- Feed requests are cursor-paginated (`limit` + optional `cursor`) and duplicate IDs are ignored.
- Only the active video owns an `AVPlayer`; the next playable URL is prepared as an `AVPlayerItem`.
- Switching videos pauses and releases the previous player/item references.
- Retry and pull-to-refresh are available.
- Removed likes, comments, and other social UI/state from the app.
- Missing `video_url` is shown honestly; `share_url` is only offered as an external page link.

## Project identifiers

- iOS bundle ID: `com.jionzyk.douyinlite`
- Watch bundle ID: `com.jionzyk.douyinlite.watchkitapp`
- Watch companion bundle ID: `com.jionzyk.douyinlite`
- Deployment targets: iOS 17.0, watchOS 10.0

These values are preserved from the supplied v0.2 `project.yml`. Verify them against the signing team and generated Xcode project before archiving.

## Configure the backend

Edit `Shared/FeedService.swift` and replace:

```swift
https://YOUR-DOMAIN.example/v1/douyin/hot
```

with your own HTTPS backend URL. Do not put Douyin `client_secret`, access tokens, or refresh tokens in the app.

The backend must return the schema documented in `SERVER_API_CONTRACT.md`. `video_url` must be a direct, authorized MP4/HLS media URL. A cover URL or Douyin playback/share page URL is not a media stream.

## Generate the Xcode project

Requires macOS, Xcode, and XcodeGen:

```bash
brew install xcodegen
cd DouyinLite-v0.3
xcodegen generate
open DouyinLite.xcodeproj
```

Select the iOS app scheme, set your Apple Development Team, and verify the Watch target is embedded and its companion identifier is correct. Then build/run on a paired iPhone and Apple Watch.

## IPA / signing

This source archive does not contain a signed IPA. Building and signing the paired iPhone + Watch app requires macOS with Xcode, a valid Apple signing identity/team, and the target devices/provisioning setup. This Linux execution environment cannot run Xcode or produce a trustworthy signed IPA.

## Current source limitation

The app is ready to consume an authorized feed backend, but no backend domain or authorized direct video media URLs were supplied. Therefore live public Douyin feed playback is not yet enabled. The app does not scrape Douyin, use undocumented endpoints, replay cookies, bypass signatures, or claim that a playback-page URL is an AVPlayer stream.
