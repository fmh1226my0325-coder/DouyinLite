import SwiftUI
import AVKit

struct FeedView: View {
    @StateObject private var service = FeedService()
    @StateObject private var playback = VideoPlaybackManager()
    @State private var currentVideoID: String?

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.ignoresSafeArea()

                if service.videos.isEmpty {
                    emptyState
                } else {
                    ScrollView(.vertical) {
                        LazyVStack(spacing: 0) {
                            ForEach(service.videos) { video in
                                VideoFeedPage(
                                    video: video,
                                    isActive: currentVideoID == video.id,
                                    playback: playback
                                )
                                .frame(width: geometry.size.width, height: geometry.size.height)
                                .id(video.id)
                                .onAppear {
                                    Task { await service.loadNextPageIfNeeded(after: video) }
                                }
                            }
                        }
                        .scrollTargetLayout()
                    }
                    .scrollIndicators(.hidden)
                    .scrollTargetBehavior(.paging)
                    .scrollPosition(id: $currentVideoID)
                    .ignoresSafeArea()
                    .refreshable {
                        playback.stopAndRelease()
                        currentVideoID = nil
                        await service.loadInitialPage(force: true)
                        currentVideoID = service.videos.first?.id
                    }
                }
            }
            .ignoresSafeArea()
            .background(.black)
            .task {
                await service.loadInitialPage()
                if currentVideoID == nil {
                    currentVideoID = service.videos.first?.id
                }
            }
            .onChange(of: currentVideoID) { _, newID in
                guard let newID,
                      let index = service.videos.firstIndex(where: { $0.id == newID }) else {
                    playback.stopAndRelease()
                    return
                }
                let current = service.videos[index]
                playback.play(current)
                let next = index + 1 < service.videos.count ? service.videos[index + 1] : nil
                playback.preload(next)
                Task { await service.loadNextPageIfNeeded(after: current) }
            }
            .onDisappear {
                playback.stopAndRelease()
            }
        }
        .preferredColorScheme(.dark)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "play.rectangle").font(.system(size: 46))
            Text(service.errorMessage ?? "正在加载视频…")
                .font(.callout)
                .multilineTextAlignment(.center)
            Button("重新加载") {
                Task { await service.loadInitialPage(force: true) }
            }
            .buttonStyle(.borderedProminent)
            .disabled(service.isLoading)
        }
        .foregroundStyle(.white)
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

private struct VideoFeedPage: View {
    let video: VideoItem
    let isActive: Bool
    @ObservedObject var playback: VideoPlaybackManager

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black

            if isActive, let player = playback.player {
                VideoPlayer(player: player)
                    .ignoresSafeArea()
            } else if let coverURL = video.coverURL {
                AsyncImage(url: coverURL) { phase in
                    if let image = phase.image {
                        image.resizable().scaledToFit()
                    } else {
                        Color.black
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                Image(systemName: "play.slash")
                    .font(.system(size: 42))
                    .foregroundStyle(.white.opacity(0.7))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }

            LinearGradient(
                colors: [.clear, .black.opacity(0.72)],
                startPoint: .center,
                endPoint: .bottom
            )
            .allowsHitTesting(false)

            VStack(alignment: .leading, spacing: 8) {
                Text(video.title)
                    .font(.headline)
                    .lineLimit(3)
                Text("@\(video.author)")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.82))

                if video.videoURL == nil {
                    Text("此视频没有授权的 MP4/HLS 播放地址")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.8))
                    if let shareURL = video.shareURL {
                        Link("打开视频页面", destination: shareURL)
                            .font(.subheadline.weight(.semibold))
                    }
                } else {
                    Button {
                        playback.replay(video)
                    } label: {
                        Label("重新播放", systemImage: "arrow.clockwise")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.plain)
                }
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 22)
            .padding(.bottom, 42)
        }
        .clipped()
    }
}
