import AVKit
import SwiftUI

struct FeedView: View {
    @StateObject private var playback = VideoPlaybackManager()
    @State private var videos: [VideoItem] = []
    @State private var selectedID: String?
    @State private var isLoading = true
    @State private var loadError: String?

    private let service = FeedService()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if isLoading {
                ProgressView("正在准备公开视频…")
                    .tint(.white)
                    .foregroundStyle(.white)
            } else if let loadError {
                errorView(loadError)
            } else if videos.isEmpty {
                errorView("暂时没有可播放的视频")
            } else {
                feed
            }
        }
        .task { await load() }
        .onChange(of: selectedID) { _, newID in
            guard let newID, let video = videos.first(where: { $0.id == newID }) else { return }
            playback.play(video)
        }
    }

    private var feed: some View {
        ScrollView(.vertical) {
            LazyVStack(spacing: 0) {
                ForEach(videos) { video in
                    VideoPage(video: video, playback: playback)
                        .containerRelativeFrame(.vertical)
                        .id(video.id)
                }
            }
            .scrollTargetLayout()
        }
        .scrollIndicators(.hidden)
        .scrollTargetBehavior(.paging)
        .scrollPosition(id: $selectedID)
        .ignoresSafeArea()
        .overlay(alignment: .topLeading) {
            Text("DouyinLite · 公共演示")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.top, 10)
                .foregroundStyle(.white.opacity(0.85))
        }
    }

    private func errorView(_ message: String) -> some View {
        VStack(spacing: 14) {
            Text(message).foregroundStyle(.white)
            Button("重新加载") { Task { await load() } }
                .buttonStyle(.borderedProminent)
        }
    }

    @MainActor
    private func load() async {
        isLoading = true
        loadError = nil
        do {
            videos = try await service.loadVideos()
            selectedID = videos.first?.id
            if let first = videos.first { playback.play(first) }
        } catch {
            loadError = error.localizedDescription
        }
        isLoading = false
    }
}

private struct VideoPage: View {
    let video: VideoItem
    @ObservedObject var playback: VideoPlaybackManager

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black
            if playback.currentVideoID == video.id {
                VideoPlayer(player: playback.player)
                    .ignoresSafeArea()
            } else {
                ProgressView().tint(.white)
            }

            LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .center, endPoint: .bottom)
                .allowsHitTesting(false)

            VStack(alignment: .leading, spacing: 8) {
                Text(video.title).font(.title2.bold())
                Text(video.creator).font(.subheadline)
                Text(video.attribution).font(.caption2).foregroundStyle(.white.opacity(0.75))
                HStack {
                    Button(playback.isPlaying ? "暂停" : "播放") { playback.togglePlayback() }
                    Button("重试") { playback.retry(video) }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 54)
            .foregroundStyle(.white)
        }
        .clipped()
    }
}
