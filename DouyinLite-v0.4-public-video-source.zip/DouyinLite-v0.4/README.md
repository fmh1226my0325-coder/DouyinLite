# DouyinLite v0.4 — Public Video Playback Preview

This version is a playback-validation build using a publicly downloadable Blender Foundation sample movie.
It is **not** a Douyin feed and does not claim that the sample is Douyin content.

## Included
- iOS vertical, page-style video feed with automatic playback when the selected item changes.
- Watch app independently loads the same bundled public-video catalog and plays over its own network connection.
- Retry and play/pause controls.
- One shared AVPlayer per app process; old items are replaced when switching.
- No login, cookies, private APIs, likes, comments, download persistence, or viewing history.

## Public sample media
Big Buck Bunny — Blender Foundation, licensed under Creative Commons Attribution 3.0 (CC BY 3.0).
Source/project: https://peach.blender.org/
License: https://creativecommons.org/licenses/by/3.0/
Direct sample stream: https://download.blender.org/peach/bigbuckbunny_movies/BigBuckBunny_320x180.mp4

The direct URL is a third-party public demo stream, not an SLA-backed production CDN. It may be moved or rate-limited.
For production, replace it with a media URL you own or are authorized to distribute.

## Build
1. Install XcodeGen (`brew install xcodegen`).
2. Run `xcodegen generate`.
3. Open `DouyinLite.xcodeproj`.
4. Build scheme `DouyinLite` for iOS Simulator and `DouyinLiteWatch` for watchOS Simulator.

The GitHub Actions workflow builds simulator products only. It does not create a signed IPA or install to devices.
