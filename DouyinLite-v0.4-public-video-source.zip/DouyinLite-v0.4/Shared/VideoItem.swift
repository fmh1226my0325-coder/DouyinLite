import Foundation

struct VideoItem: Identifiable, Hashable {
    let id: String
    let title: String
    let creator: String
    let streamURL: URL
    let attribution: String

    static let publicDemo: [VideoItem] = [
        VideoItem(
            id: "big-buck-bunny",
            title: "Big Buck Bunny",
            creator: "Blender Foundation",
            streamURL: URL(string: "https://download.blender.org/peach/bigbuckbunny_movies/BigBuckBunny_320x180.mp4")!,
            attribution: "CC BY 3.0 · Blender Foundation"
        )
    ]
}
