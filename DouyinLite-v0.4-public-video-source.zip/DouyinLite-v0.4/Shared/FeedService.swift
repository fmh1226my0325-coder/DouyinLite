import Foundation

/// A deliberately small, transparent catalog of public demo media.
/// Each app process reads this catalog independently; no iPhone relay is used.
struct FeedService {
    func loadVideos() async throws -> [VideoItem] {
        try await Task.sleep(nanoseconds: 150_000_000)
        return VideoItem.publicDemo
    }
}
