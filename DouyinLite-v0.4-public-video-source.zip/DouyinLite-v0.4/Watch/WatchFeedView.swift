import AVKit
import SwiftUI

struct WatchFeedView: View {
    @StateObject private var playback = VideoPlaybackManager()
    @State private var videos: [VideoItem] = []
    @State private var index = 0
    @State private var isLoading = true
    @State private var errorMessage: String?

    private let service = FeedService()

    private var currentVideo: VideoItem? {
        guard videos.indices.contains(index) else { return nil }
        return videos[index]
    }

    var body: some View {
        VStack(spacing: 8) {
            if isLoading {
                ProgressView("加载中…")
            } else if let errorMessage {
                Text(errorMessage).font(.footnote)
                Button("重试") { Task { await load() } }
            } else if let video = currentVideo {
                Text(video.title).font(.headline).lineLimit(2)
                VideoPlayer(player: playback.player)
                    .frame(maxHeight: .infinity)
                HStack {
                    Button("上一条") { move(by: -1) }
                        .disabled(index == 0)
                    Button(playback.isPlaying ? "暂停" : "播放") { playback.togglePlayback() }
                    Button("下一条") { move(by: 1) }
                        .disabled(index >= videos.count - 1)
                }
                .font(.caption2)
                Button("重新加载视频") { playback.retry(video) }
                    .font(.caption2)
                Text(video.attribution).font(.system(size: 9)).foregroundStyle(.secondary)
            } else {
                Text("没有可播放的视频")
            }
        }
        .padding()
        .task { await load() }
    }

    @MainActor
    private func load() async {
        isLoading = true
        errorMessage = nil
        do {
            videos = try await service.loadVideos()
            index = 0
            if let video = currentVideo { playback.play(video) }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func move(by offset: Int) {
        let next = index + offset
        guard videos.indices.contains(next) else { return }
        index = next
        if let video = currentVideo { playback.play(video) }
    }
}
