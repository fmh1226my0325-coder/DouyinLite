import AVKit
import AVFoundation
import Combine
import Foundation

@MainActor
final class VideoPlaybackManager: ObservableObject {
    @Published private(set) var currentVideoID: String?
    @Published private(set) var isPlaying = false
    @Published private(set) var playbackError: String?

    let player = AVPlayer()
    private var currentURL: URL?

    func play(_ video: VideoItem) {
        guard currentVideoID != video.id || currentURL != video.streamURL else {
            player.play()
            isPlaying = true
            return
        }
        player.pause()
        player.replaceCurrentItem(with: nil)
        currentVideoID = video.id
        currentURL = video.streamURL
        playbackError = nil

        let item = AVPlayerItem(url: video.streamURL)
        player.replaceCurrentItem(with: item)
        player.automaticallyWaitsToMinimizeStalling = true
        player.play()
        isPlaying = true
    }

    func togglePlayback() {
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    func retry(_ video: VideoItem) {
        player.pause()
        player.replaceCurrentItem(with: nil)
        currentVideoID = nil
        currentURL = nil
        playbackError = nil
        play(video)
    }

    func stop() {
        player.pause()
        player.replaceCurrentItem(with: nil)
        currentVideoID = nil
        currentURL = nil
        isPlaying = false
    }
}
